package tests;

public class TestEmoji {
	public static void main(String[] args) {
        System.out.println("\uD83D\uDC79"); // Imprime 👹
        System.out.println("\uD83D\uDDE1️"); // Imprime 🗡️
        System.out.println("\uD83D\uDEE1️"); // Imprime 🛡️
        System.out.println("\uD83E\uDD3A"); // Imprime 🤺
        System.out.println("\uD83D\uDEAA"); // Imprime 🚪
    }
}

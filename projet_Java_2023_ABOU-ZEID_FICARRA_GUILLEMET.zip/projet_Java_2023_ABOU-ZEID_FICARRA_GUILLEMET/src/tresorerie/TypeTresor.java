package tresorerie;

public enum TypeTresor {

	ARME, ARMURE;
}
